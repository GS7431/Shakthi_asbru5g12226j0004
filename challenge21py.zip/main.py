class BankAccount:

  def__initi__(self,account_number,account_holder_name,
            initial_balance==0.0):
  self.__account_number=account_number
  self.__account_holder_name=account_holder_name
  self.__account_balance=initial_balance
  def deposite(self,amount):
    if amount>0:
      self.__account_balance+=amount
      #(self.__account_balance=self.__account_balance+=amount)
      print(""Deposite${}.new balance:${}.format(amount,self.__account balance))
      else:
      print("Invalid deposite amount.please deposite a positive amount")
      def withdrawl(self,amount):
      if amount>0 and amount<=self.__account.balance:
      self.__account_balance=self.__account_balance_amount
      print("withdraw${}.new balance:{}.format"(amount,self.__account_balance))
      else:
      print("Invalid withdraw amount or insufficient balance.")def display_balance(self):
      print("Acxount balance for{}(account{}):{}"format)
      self.__account_holder_name,self.__account_number,
      sef.__account_balance))
      # create account instance of the Bank account class
      account=BankAccount(account_numbr="123456789").account-holder name_"Hari prabhu".initial balance=5000.0)
      # Test deposite and withdrawl funtionality
      account.display_balance()
      account.deposite(500.0)
      account.withdrawl(200.0)
      account.display balance()