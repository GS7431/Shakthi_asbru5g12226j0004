def is_leap_year(year):
  if year %4==0:
    if year%100==0:
      if year %400==0:
        return True
      else :
        return false
    else :
      return true
  else :
    return false
year=int(input("Enter a year:"))
if is_leap_year(year):
   print (year,"is a leap year")
else:
  print(year,"is not a leap year")